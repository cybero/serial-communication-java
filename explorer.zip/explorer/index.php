<?php  

ini_set('display_errors', 1);

require_once 'jsonRPCClient.php';
 

$username='user';
$password='aaa';
$zclassic = new jsonRPCClient('http://'.$username.':'.$password.'@144.76.12.21:8232/');

/*** BEGIN: Conexión con API de coinmarketcap.northpole.ro ***/
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, 'http://coinmarketcap.northpole.ro/api/v5/ZCL.json');
$result = curl_exec($ch);
curl_close($ch);

$obj = json_decode($result);
/*** END: Conexión con API de coinmarketcap.northpole.ro ***/


/*** BEGIN: Conexión con API de classic.zcha.in ***/
$ch2 = curl_init();
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_URL, 'https://classic.api.zcha.in/v1/mainnet/network');
$result = curl_exec($ch2);
curl_close($ch2);

$obj2 = json_decode($result);
/*** END: Conexión con API de classic.zcha.in ***/

$getmininginfo=$zclassic->getmininginfo();

/***	CHAIN HEIGHT	***/ 
$Chain_Height=$getmininginfo['blocks'];

/***	NETWORK HASHRATE	***/ 
$Network_Hashrate=$getmininginfo['networkhashps'];

/***	DIFFICULTY	***/ 
$Difficulty=$zclassic->getdifficulty();

/***	PRICE (EUR)	***/
$price=$obj->price->eur;

/***	TOTAL MONETARY BASE	***/
$total_monetary_base=$obj->availableSupplyNumber;

/***	MARKET CAP	***/
$market_cap=$obj->marketCap->eur;

/***	TRANSACTIONS	***/
$transactions=$obj2->transactions;

/***	BLOCKTIME	***/
$block_time=$obj2->meanBlockTime;


/***	BEGIN: Recent Blocks	***/

$bloque1=$Chain_Height;  // bloque 1

$bloque_ultimo=$zclassic->getbestblockhash();
$bloque=$zclassic->getblock($bloque_ultimo);
$tx=$bloque ['tx'][0];
$Txns1=sizeof( $bloque['tx']);	//Txns

$size1=$bloque['size'];    


$time1=$zclassic->getrawtransaction($tx,1)['time'];
$time1=time()-$time1;
$time1 = floor($time1 / 60);

$minero1=$zclassic->getrawtransaction($tx,1)['vout']['0']['scriptPubKey']['addresses']['0'];


$bloque2=$Chain_Height-1;
$hash=$zclassic->getblockhash($bloque2);
$bloque=$zclassic->getblock($hash);
$tx=$bloque ['tx'][0];
$Txns2=sizeof( $bloque['tx']);	//Txns

$size2=$bloque['size']; 

$time2=$zclassic->getrawtransaction($tx,1)['time'];
$time2=time()-$time2;
$time2 = floor($time2 / 60);


$minero2=$zclassic->getrawtransaction($tx,1)['vout']['0']['scriptPubKey']['addresses']['0'];
  

$bloque3=$Chain_Height-2;
echo "\n";

$hash=$zclassic->getblockhash($bloque3);
echo "\n";
$bloque=$zclassic->getblock($hash);
$tx=$bloque ['tx'][0];
$Txns3=sizeof( $bloque['tx']);	//Txns

$size3=$bloque['size']; 

$time3=$zclassic->getrawtransaction($tx,1)['time'];
$time3=time()-$time3;
$time3 = floor($time3 / 60);


$minero3=$zclassic->getrawtransaction($tx,1)['vout']['0']['scriptPubKey']['addresses']['0'];


$bloque4=$Chain_Height-3;
echo "\n";

$hash=$zclassic->getblockhash($bloque4);
echo "\n";
$bloque=$zclassic->getblock($hash);
$tx=$bloque ['tx'][0];
$Txns4=sizeof( $bloque['tx']);	//Txns

$size4= $bloque['size']; 

$time4=$zclassic->getrawtransaction($tx,1)['time'];
$time4=time()-$time4;
$time4 = floor($time4 / 60);


$minero4=$zclassic->getrawtransaction($tx,1)['vout']['0']['scriptPubKey']['addresses']['0'];


$bloque5=$Chain_Height-4;
echo "\n";

$hash=$zclassic->getblockhash($bloque5);
echo "\n";
$bloque=$zclassic->getblock($hash);
$tx=$bloque ['tx'][0];
$Txns5=sizeof( $bloque['tx']);	//Txns
$size5=$bloque['size'];

$time5=$zclassic->getrawtransaction($tx,1)['time'];
$time5=time()-$time5;
$time5 = floor($time5 / 60);


$minero5=$zclassic->getrawtransaction($tx,1)['vout']['0']['scriptPubKey']['addresses']['0'];

/***	END: Recent Blocks	***/


?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Zclassic - ZCL - Explorer</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/themify-icons.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/flexslider.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/lightbox.min.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/ytplayer.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/theme-orange.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/custom.css" rel="stylesheet" type="text/css" media="all" />
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link href='http://fonts.googleapis.com/css?family=Lato:300,400%7CRaleway:100,400,300,500,600,700%7COpen+Sans:400,500,600' rel='stylesheet' type='text/css'>
    </head>
    <body class="scroll-assist">
        <div class="nav-container">
            <a id="top"></a>
            <nav class="bg-light">
                <div class="nav-bar">
                    <div class="module left">
                        <a href="index.html">
                            <img class="logo logo-light" alt="Foundry" src="img/logo-light.png" />
                            <img class="logo logo-dark" alt="Foundry" src="img/logo-dark.png" />
                        </a>
                    </div>
                    <div class="module widget-handle mobile-toggle right visible-sm visible-xs">
                        <i class="ti-menu"></i>
                    </div>
                    <div class="module-group right">
                        <div class="module left">
                            <ul class="menu">
                                <li>
                                    <a href="index.html">
                                        Home
                                    </a>
                                </li>
                                <li>
                                    <a href="blocks.html">
                                        blocks
                                    </a>
                                </li>
                                <li>
                                    <a href="transactions.html">
                                        transactions
                                    </a>
                                </li>
                                <li>
                                    <a href="accounts.html">
                                        accounts
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="module widget-handle search-widget-handle left">
                            <div class="search">
                                <i class="ti-search"></i>
                                <span class="title">Search Site</span>
                            </div>
                            <div class="function">
                                <form class="search-form">
                                    <input type="text" placeholder="Type Here" />
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
        <div class="main-container">
            <section class="image-bg overlay parallax">
                <div class="background-image-holder">
                    <img alt="Background" class="background-image" src="img/bgecl5.jpg" />
                </div>
                <div class="container">
                    <div class="col-sm-3">
                            <div class="feature feature-1 bordered text-center bg-light">
                                <div class="text-center">
                                    <i class="fa fa-chain fa-3x"></i>
                                    <h5 class="uppercase">Chain Height</h5>
                                </div>
                                <h4>
                                    <?php echo $Chain_Height;?>
                                </h4>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="feature feature-1 bordered text-center bg-light">
                                <div class="text-center">
                                    <i class="fa fa-globe fa-3x"></i>
                                    <h5 class="uppercase">Net Hashrate</h5>
                                </div>
                                <h4>
                                    <?php echo $Network_Hashrate;?>
                                </h4>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="feature feature-1 bordered text-center bg-light">
                                <div class="text-center">
                                    <i class="fa fa-wrench fa-3x"></i>
                                    <h5 class="uppercase">Difficulty</h5>
                                </div>
                                <h4>
                                    <?php echo number_format($Difficulty, 3, '.', '');?>
                                </h4>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="feature feature-1 bordered text-center bg-light">
                                <div class="text-center">
                                    <i class="fa fa-clock-o fa-3x"></i>
                                    <h5 class="uppercase">Block Time</h5>
                                </div>
                                <h4>
                                    <?php echo number_format($block_time, 3, '.', '');?>
                                </h4>
                            </div>
                        </div>
                    </div>
                <div class="container">
                    <div class="col-sm-3">
                            <div class="feature feature-1 bordered text-center bg-light">
                                <div class="text-center">
                                    <i class="fa fa-eur fa-3x"></i>
                                    <h5 class="uppercase">Price</h5>
                                </div>
                                <h4>
                                    <?php echo number_format($price, 3, '.', '');?> EUR
                                </h4>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="feature feature-1 bordered text-center bg-light">
                                <div class="text-center">
                                    <i class="fa fa-university fa-3x"></i>
                                    <h5 class="uppercase">Total ZCL</h5>
                                </div>
                                <h4>
                                    <?php echo $total_monetary_base;?>
                                </h4>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="feature feature-1 bordered text-center bg-light">
                                <div class="text-center">
                                    <i class="fa fa-bar-chart fa-3x"></i>
                                    <h5 class="uppercase">Market Cap</h5>
                                </div>
                                <h4>
                                    <?php echo number_format($market_cap, 3, '.', '');?> EUR
                                </h4>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="feature feature-1 bordered text-center bg-light">
                                <div class="text-center">
                                    <i class="fa fa-exchange fa-3x"></i>
                                    <h5 class="uppercase">Transactions</h5>
                                </div>
                                <h4>
                                    <?php echo $transactions;?>
                                </h4>
                            </div>
                        </div>
                </div>
             </section>
             <section>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="feature feature-1 boxed">
                                <div class="text-center">
                                    <i class="fa fa-cubes fa-4x"></i>
                                    <h4>Recent Blocks</h4>
                                </div>
                                <div class="container">
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <h6 class="uppercase">HEIGHT</h6>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <h6 class="uppercase">Age</h6>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <h6 class="uppercase">TXNS</h6>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <h6 class="uppercase">SIZE</h6>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <h6 class="uppercase">MINER</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $bloque1;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $time1." minutes";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $Txns1;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $size1." B";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <p><?php echo substr($minero1, 0, 11);echo "...";?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $bloque2;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $time2." minutes";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $Txns2;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $size2." B";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <p><?php echo substr($minero2, 0, 11);echo "...";?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $bloque3;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $time3." minutes";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $Txns3;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $size3." B";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <p><?php echo substr($minero3, 0, 11);echo "...";?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $bloque4;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $time4." minutes";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $Txns4;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $size4." B";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <p><?php echo substr($minero4, 0, 11);echo "...";?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $bloque5;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $time5." minutes";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $Txns5;?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo $size5." B";?></p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p><?php echo substr($minero5, 0, 11);echo "...";?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            </div>
                        <div class="col-sm-6">
                            <div class="feature feature-1 boxed">
                                <div class="text-center">
                                    <i class="fa fa-handshake-o fa-4x"></i>
                                    <h4>Recent Transactions</h4>
                                </div>
                                <div class="container">
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <h6 class="uppercase">Hash</h6>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <h6 class="uppercase">Type</h6>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <h6 class="uppercase">Age</h6>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <h6 class="uppercase">Shielded</h6>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <h6 class="uppercase">Transparent</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Hash</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Type</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Age</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Shielded</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <p>Transparent</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Hash</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Type</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Age</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Shielded</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <p>Transparent</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Hash</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Type</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Age</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Shielded</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <p>Transparent</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Hash</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Type</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Age</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Shielded</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <p>Transparent</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row">
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Hash</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Type</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Age</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-1">
                                            <div class="mb32">
                                                <p>Shielded</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="mb32">
                                                <p>Transparent</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
           
            <footer class="footer-1 bg-dark">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6">
                            <span class="sub">&copy; Z CLASSIC - 2016</span>
                        </div>
                        <div class="col-sm-6 text-right">
                            <ul class="list-inline social-list">
                                <li>
                            <a href="https://github.com/z-classic/zclassic">
                                <i class="fa fa-github-alt"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/ZclassicCoin">
                                <i class="fa fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.reddit.com/r/ZClassic/">
                                <i class="fa fa-reddit-alien"></i>
                            </a>
                        </li>
                        <li>
                            <a href="http://zclassic.herokuapp.com/">
                                <i class="fa fa-slack"></i>
                            </a>
                        </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <a class="btn btn-sm fade-half back-to-top inner-link" href="#top">Top</a>
            </footer>
        </div>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/flickr.js"></script>
        <script src="js/flexslider.min.js"></script>
        <script src="js/lightbox.min.js"></script>
        <script src="js/masonry.min.js"></script>
        <script src="js/twitterfetcher.min.js"></script>
        <script src="js/spectragram.min.js"></script>
        <script src="js/ytplayer.min.js"></script>
        <script src="js/countdown.min.js"></script>
        <script src="js/smooth-scroll.min.js"></script>
        <script src="js/parallax.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>